import pygame
from settings import TILE, TILE_ROOT
from draw import Camera
from object import Tile, Player, Enemy, SpritesCollection, Entity


SpritesCollection.append_sprite('sand', 'gfx/sand.png')
[SpritesCollection.append_sprite(f'block-{i}', f'gfx/block-{i}.png') for i in range(9)]
SpritesCollection.append_sprite('player', 'gfx/player.png')
SpritesCollection.append_sprite('enemy', 'gfx/enemy.png')
SpritesCollection.append_sprite('bullet', 'gfx/bullet.png')
SpritesCollection.resize(TILE/TILE_ROOT)


class World:
    def __init__(self, map):
        self.map = map
        self.player = None

    def block_load(self, x_num, y_num, x_max, y_max) -> int:
        value = 4
        top = self.map[max(y_num-1, 0)][x_num] == 1
        down = self.map[min(y_num+1, y_max)][x_num] == 1
        left = self.map[y_num][max(x_num-1, 0)] == 1
        right = self.map[y_num][min(x_num+1, x_max)] == 1
        if not left and not top and right and down: value = 0
        if not top and left and right: value = 1
        if not top and not right and left and down: value = 2
        if not left and top and down: value = 3
        if not right and top and down: value = 5
        if not left and not down and top and right: value = 6
        if not down and left and right: value = 7
        if not right and not down and top and left: value = 8

        return value

    def load_world(self):
        for y_num, y_value in enumerate(self.map):
            for x_num, x_value in enumerate(y_value):
                left_top = {'left': x_num*TILE, 'top': y_num*TILE}
                obj = Tile(**left_top, image='sand')
                Camera.add_sprite(obj)
                if x_value == 1:
                    block_type = self.block_load(x_num, y_num, len(y_value)-1, len(self.map)-1)
                    obj = Tile(**left_top, image=f'block-{block_type}', layer=2)
                    Camera.add_sprite(obj)
                if x_value == 2:
                    self.player = Player(**left_top, image='player', HP=20, damage=6, speed=0.55, layer=1)
                    Camera.add_sprite(self.player)
                if x_value == 3:
                    obj = Enemy(**left_top, image='enemy', HP=15, damage=2, speed=1, layer=1)
                    Camera.add_sprite(obj)


world = World([
    [0, 1, 1, 0, 0, 0, 3],
    [2, 1, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 0, 1, 1],
    [0, 0, 1, 1, 0, 1, 1],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 0, 0]
])
world.load_world()

