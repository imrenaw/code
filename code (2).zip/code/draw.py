import pygame


class Camera:
    SPRITES = []

    @staticmethod
    def blit(display):
        for sprite in sorted(Camera.SPRITES, key=lambda sprite: sprite.layer):
            display.blit(sprite.image, sprite.topleft)

    @staticmethod
    def add_sprite(obj):
        Camera.SPRITES.append(obj)
