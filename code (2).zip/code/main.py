from loading import *


class Main:
    def __init__(self):
        self.clock = pygame.time.Clock()
        self.win = pygame.display.set_mode((400, 300), pygame.SCALED, vsync=1)
        self.player = world.player
        pygame.display.set_caption('Remake')

    def update(self):
        game = True
        while game:
            self.win.fill((0, 0, 0))
            Camera.blit(self.win)
            [entity.update() for entity in Entity.Entities]
            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game = False

            self.clock.tick(60)


if __name__ == '__main__':
    main = Main()
    main.update()
