import os


def load_file(file_path: str):
    return f'{PATH}/{file_path}'


PATH = os.getcwd()

TILE_ROOT = 16
TILE = TILE_ROOT*2
