import pygame


class Collision:
    COLLISION: list[pygame.rect.Rect] = []

    def append_collision(self, obj):
        pass

    def collision(self):
        pass

