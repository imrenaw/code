import pygame


class Image(pygame.rect.Rect):
    def __init__(self, image, **kwargs):
        super().__init__(**kwargs)
        self.image = image

    def blit(self):
        pass

    def update(self):
        pass


class Button(pygame.rect.Rect):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        pass

    def click(self):
        pass

    def move_cursor(self):
        pass

    def update(self):
        pass


class Text(pygame.rect.Rect):
    def __init__(self, text, font, color, **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self.font = font
        self.color = color


class EventManager:
    def __init__(self):
        self.objects = []

    def update(self):
        [obj.update for obj in self.objects]


