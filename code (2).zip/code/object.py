import pygame
import time
from settings import load_file, TILE
from abc import ABC, abstractmethod
from draw import Camera


class SpritesCollection:
    SPRITES: dict[str: pygame.Surface] = {}

    @staticmethod
    def append_sprite(image_str: str, image: str):
        SpritesCollection.SPRITES[image_str] = pygame.image.load(load_file(image))

    @staticmethod
    def resize(size):
        for key, sprite in SpritesCollection.SPRITES.items():
            if size > 0:
                image = pygame.transform.scale(sprite,
                                               (sprite.get_width() * size,
                                                sprite.get_height() * size))
            else:
                image = pygame.transform.scale(sprite,
                                               (sprite.get_width() * size,
                                                sprite.get_height() * size))
            SpritesCollection.SPRITES[key] = image


class Sprite(pygame.rect.Rect):
    def __init__(self, image: str, size: int = TILE, layer: int = 0, **kwargs):
        super().__init__(kwargs['left'], kwargs['top'], size, size)
        self.image = SpritesCollection.SPRITES[image]
        self.layer = layer


class Tile(Sprite):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class Entity(Sprite):
    Entities = []

    def __init__(self, speed: float, **kwargs):
        super().__init__(**kwargs)
        Entity.Entities.append(self)
        self.speed = speed
        self.image_list = [pygame.transform.rotate(self.image, angle) for angle in range(0, 360, 90)]

    def move_up(self):
        self.y -= self.speed
        self.image = self.image_list[0]

    def move_down(self):
        self.y += self.speed
        self.image = self.image_list[2]

    def move_left(self):
        self.x -= self.speed
        self.image = self.image_list[1]

    def move_right(self):
        self.x += self.speed
        self.image = self.image_list[3]

    def update(self):
        pass


class EntityHPSystem(Entity, ABC):
    def __init__(self, HP, damage, **kwargs):
        super().__init__(**kwargs)
        self.HP = HP
        self.damage = damage

    @abstractmethod
    def attack(self):
        ...


class Bullet(Entity):
    def __init__(self, damage, direct, **kwargs):
        super().__init__(**kwargs)
        self.damage = damage
        self.direct = direct

    def hit(self):
        pass

    def update(self):
        if self.direct == 'up': self.move_up()
        if self.direct == 'down': self.move_down()
        if self.direct == 'left': self.move_left()
        if self.direct == 'right': self.move_right()


class Enemy(EntityHPSystem):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def AI(self):
        pass

    def attack(self):
        pass


class Player(EntityHPSystem):
    KEYS: dict = {'up': pygame.K_w, 'down': pygame.K_s, 'left': pygame.K_a, 'right': pygame.K_d, 'attack': pygame.K_SPACE}

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.direct = 'up'
        self.last_shot = 0

    def control(self):
        keys = pygame.key.get_pressed()
        if keys[Player.KEYS['up']]:
            self.move_up()
            self.direct = 'up'
        elif keys[Player.KEYS['down']]:
            self.move_down()
            self.direct = 'down'
        elif keys[Player.KEYS['left']]:
            self.move_left()
            self.direct = 'left'
        elif keys[Player.KEYS['right']]:
            self.move_right()
            self.direct = 'right'

        if keys[Player.KEYS['attack']] and time.time() - self.last_shot > 1.5:
            self.attack()

    def update(self):
        self.control()

    def attack(self):
        self.last_shot = time.time()
        Camera.add_sprite(Bullet(top=self.centery-2, left=self.centerx-2, width=2, height=4,
                                 layer=0.5, direct=self.direct, image='bullet', damage=self.damage, speed=2))
